LLVM_DST_ROOT = "/home/gpli/Downloads/llvm-2.9-build"
LLVM_SRC_ROOT = "/home/gpli/Downloads/llvm-2.9"
LLVM_GXX_BIN_DIR = ""
